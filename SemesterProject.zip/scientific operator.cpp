#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double num1, num2, result;
    char op;
    cout << "Enter the first number: "<<endl;
    cin >> num1;
    cout << "Enter the operator (+, -, *, /, ^,mod, sin, cos, tan, log, ln): "<<endl;
    cin >> op;
    cout << "Enter the second number: "<<endl;
    cin >> num2;
    switch (op) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 == 0) {
                cout << "Math Error: Cancel." << endl;
                return 0;
            }
            result = num1 / num2;
            break;
        case '^':
            result = pow(num1, num2);
            break;
        case 's':
            result = sin(num1);
            break;
        case 'c':
            result = cos(num1);
            break;
        case 't':
            result = tan(num1);
            break;
        case 'l':
            result = log10(num1);
            break;
        case 'n':
            result = log(num1);
            break;
        default:
            cout << "Error: invalid operator." << endl;
            return 0;
    }
    cout << "Result: " << result << endl;
    return 0;
}
	

